from traits.api import HasTraits, Instance, Enum
from traitsui.api import View, Item
from chaco.api import Plot, ArrayPlotData
from enable.component_editor import ComponentEditor
from numpy import linspace, sin

#class FidPlot(HasTraits):
#    plot = Instance(Plot)
#
#    spectrum_index = Enum([str(i) for i in range(len(fid.data))])
#
#    traits_view = View(
#        Item('spectrum_index', label="FID"),
#        Item('plot',editor=ComponentEditor(), show_label=True),
#        width=1000, height=500, resizable=True, title="NMR Plot")
#
#    def __init__(self, fid):
#        super(FidPlot, self).__init__()
#
#        x = linspace(15, -2, len(fid.data[1]) )
#        self.data = dict(zip([str(i) for i in range(len(fid.data))], fid.data))
#        self.plotdata = ArrayPlotData(x=x, y=self.data['0'])
#
#        plot = Plot(self.plotdata)
#        plot.plot(("x", "y"), type="line", color="black")
#        plot.title = "spectrum"
#
#        self.plot = plot
#
#    def _spectrum_index_changed(self):
#        self.plotdata.set_data("y", self.data[self.spectrum_index])

class Base(object):

    def dala(self, s):
        print 'hos ja %s'%(s)
    
if __name__ == "__main__":
    #LinePlot().configure_traits()
    print 'This module has to be imported as a submodule of nmrpy'
    pass
